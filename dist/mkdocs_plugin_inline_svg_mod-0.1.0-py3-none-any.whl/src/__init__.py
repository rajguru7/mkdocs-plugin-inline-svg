# __init__.py
from .plugin import InlineSvgPlugin
